#include <REGX51.H>
sbit key=P3^0;
unsigned char i;
unsigned char count;
unsigned int flag;
unsigned char sec;
unsigned char code seg[]={
0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,
};
unsigned char code dig[]={
0x01,0x02,0x04,0x08};
void delay(unsigned int xms)
{
	unsigned char data i, j;
while(xms--)
{
	i = 2;
	j = 199;
	do
	{
		while (--j);
	} while (--i);
}
}
void timeinit()
{
	EA=1;
	ET0=1;
	TMOD=0x01;
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	TR0=0;
}
void keynum()
{
	if(count==1)
	{
	for(i=0;i<4;i++)
		{
			P2=dig[i];
			P0=seg[i+1];
			delay(1);
		}
	}
	else
	if(count==2)
	{
		TR0=1;
		P2=dig[0];
		P0=seg[sec/10];
		delay(1);
		P2=dig[1];
		P0=seg[sec%10];
		delay(1);
	}
	else
	{
		TR0=0;
	P0=seg[1];
	P2=dig[0];
	}
}
void timer0() interrupt 1
{
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	flag++;
	if(flag==20)
	{
		flag=0;
		sec++;
		sec %= 60;
	}
	
}
 
void main()
{
	timeinit();
	while(1)
	{
if(key==0)
{
	delay(1);
if(key==0)
{
	count++;
	while(key==0);
}
if(count==3)
	count=0;
}
keynum();
	}
}
