#include "STC12C5A60S2.h"
#include <I2C.H>

#define  PCF8591 0x90    

bit DACconversion(unsigned char sla,unsigned char c,  unsigned char Val);
void delay(unsigned int ms);

void main(void) 
{
 int i;
 while(1)
 { 
   for (i=0; i<256; i++)  {
     DACconversion(PCF8591, 0x40, i);
     delay(1);
   }
   for (i=255; i>=0; --i)  {
     DACconversion(PCF8591, 0x40, i);
     delay(1);
   }
 }

}

bit DACconversion(unsigned char sla,unsigned char c,  unsigned char Val)
{
   Start_I2c();              
   SendByte(sla);            
   if(ack==0)return(0);
   SendByte(c);              
   if(ack==0)return(0);
   SendByte(Val);            
   if(ack==0)return(0);
   Stop_I2c();               
   return(1);
}

void delay(unsigned int ms)   
{
    unsigned int i,j;
    for(i=0;i<ms;i++)
        for(j=0;j<120;j++);
}
