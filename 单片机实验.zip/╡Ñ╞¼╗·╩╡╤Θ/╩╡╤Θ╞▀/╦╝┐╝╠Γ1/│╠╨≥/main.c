#include "STC12C5A60S2.h"
#include <I2C.H>

#define uchar unsigned char
#define uint unsigned int
#define  PCF8591 0x90    // PCF8591????
#define THCO   0xf8  // 11.0592MHZ?????
#define TLCO   0xcb	 // 2ms?????????

unsigned char Data_Buffer[4]={1,2,3,4};
uchar code Duan[17]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71,0x76};

sbit P24=P2^4;		// 4???????
sbit P25=P2^5;
sbit P26=P2^6;
sbit P27=P2^7;

bit flag=0;
unsigned char ch=0;

bit DACconversion(unsigned char sla,unsigned char c,  unsigned char Val);
bit ISendByte(unsigned char sla,unsigned char c);
unsigned char IRcvByte(unsigned char sla);

void main(void) 
{
 unsigned int v;
 unsigned char AD_CHANNEL=1;
 unsigned int  D[5]={0,0,0,0,255};

 TMOD=0x11;		  	
 TH0=THCO;		  
 TL0=TLCO;
 TR0=1;			  	
 ET0=1;				 
 EA=1;				

	while(1)
	{ 
	  if(flag==1)
	  {
			flag=0;
			if(ch++>=4)
				ch=0;
		switch(ch) {
	    case 0:ISendByte(PCF8591,0x40);
		v=IRcvByte(PCF8591);  
break;
case 1:ISendByte(PCF8591,0x41);
		v=IRcvByte(PCF8591);  
break;	
case 2:ISendByte(PCF8591,0x42);
		v=IRcvByte(PCF8591);  
break;	
case 3:ISendByte(PCF8591,0x43);
		v=IRcvByte(PCF8591);  
break;				
		}
	    Data_Buffer[0]=0;
	    Data_Buffer[1]=v/100%10;
	    Data_Buffer[2]=v/10%10;
		Data_Buffer[3]=v%10;
		}
   }
}

void timer0() interrupt 1	 // ?????????
{
 static unsigned int count=0;
 static unsigned char Bit=0;

 TH0=THCO;
 TL0=TLCO;

 Bit++;	
 if(Bit>=4)Bit=0;
 P2|=0xf0;					
 P0=Duan[Data_Buffer[Bit]];	
 switch(Bit)				
 {
  case 0: P24=0;break;
  case 1: P25=0;break;
  case 2: P26=0;break;
  case 3: P27=0;break;
 }

 count++;
 if(count>=250)				
 {
    count=0;   
    flag=1;	
 }             
}

bit DACconversion(unsigned char sla,unsigned char c,  unsigned char Val)
{
   Start_I2c();              
   SendByte(sla);            
   if(ack==0)return(0);
   SendByte(c);              
   if(ack==0)return(0);
   SendByte(Val);            
   if(ack==0)return(0);
   Stop_I2c();               
   return(1);
}

bit ISendByte(unsigned char sla,unsigned char c)
{
   Start_I2c();              
   SendByte(sla);            
   if(ack==0)return(0);
   SendByte(c);              
   if(ack==0)return(0);
   Stop_I2c();               
   return(1);
}

unsigned char IRcvByte(unsigned char sla)
{  unsigned char c;

   Start_I2c();          
   SendByte(sla+1);      
   if(ack==0)return(0);
   c=RcvByte();          

   Ack_I2c(1);           
   Stop_I2c();           
   return(c);
}
