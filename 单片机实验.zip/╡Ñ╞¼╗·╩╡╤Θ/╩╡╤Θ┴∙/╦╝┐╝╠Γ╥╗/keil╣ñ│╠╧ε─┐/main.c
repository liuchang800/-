#include <REGX52.H> 

void UART_Init() 
{
    SCON = 0x50; 
    TMOD = 0x20; 
    TH1 = 0xFD; 
    TL1 = 0xFD; 
    TR1 = 1; 
}

void UART_SendByte(unsigned char Byte) 
{
    SBUF = Byte; 
    while (!TI); 
    TI = 0; 
}

void main()
{
    UART_Init(); 
    while (1)
    {
			UART_SendByte(0x55); 
    }
}