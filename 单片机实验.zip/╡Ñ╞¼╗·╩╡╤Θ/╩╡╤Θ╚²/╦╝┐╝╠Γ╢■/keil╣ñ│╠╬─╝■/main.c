#include <REGX51.H>
sbit key=P3^2;
void delay(unsigned char n)	
{
	unsigned char data i, j, k;

	for(k = 0; k < n; k++) 
	{
		i = 98;
		j = 67;
		do
		{
			while (--j);
		} while (--i);
	}
}
void main()
{
	P2=0xff;
	EA=1;
	IT0=1;
	EX0=1;
	while(1)
	{
		P2=0xf0;
	}
}
void int0() interrupt 0 using 1
{
	unsigned char count=0;
	int i;
	while(1)
	{
		if(key==0)
		{
			delay(1);
		if(key==0)
		{
			count++;
		}
		while(key==0);
	}
		if(count==4)
				break;
		switch(count)
		{
			case 1:
			for(i=0;i<3;i++)
			{
				P2=~(0x01<<i);
				delay(2);
			}
			break;
			case 2:
				P2=0xfc;
			delay(2);
			P2=0xf9;
			delay(2);
			break;
			case 3:
				P2=0xf8;
			delay(2);
			P2=0xff;
			delay(2);	
		}	
	}
}

