#include <reg51.h> 
sbit key = P3^2; 
void delay(unsigned int ms) 
{
    unsigned int i,j;
    for(i=0;i<ms;i++)
        for(j=0;j<120;j++);
}
void int0() interrupt 0 using 1
{
	P2=0xFF;
    while(P2!=0xf0)
		{
			if(key==0)
				delay(10);
			if(key==0)
			{
				P2--;
				delay(10);
				while(key==0);
				delay(10);
			}
				}
}

void main() 
{
    EA=1;
IT0=1;
EX0=1;	
	P2=0xff;
    while(1)
		{
			P2=0xf0;	
		}
}

