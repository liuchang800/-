#include <REGX51.H>
sbit key=P3^0;
unsigned int count;
unsigned int ledmode=1;
void delay(unsigned char xms)	
{
	unsigned char data i, j;

	while(xms--)
	{
	i = 2;
	j = 199;
	do
	{
		while (--j);
	} while (--i);
}
}
unsigned int led()
{
	if(key==0)
	{
		delay(10);
		if(key==0)
		{
			ledmode++;
			if(ledmode>=2)
				ledmode=0;
		}
		while(key==0);
	}
	return ledmode;
}

void main()
{
	EA=1;
	ET0=1;
	TMOD=0x01;
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	P2=0xff;
while(1)
{
	if(led())
		TR0=0;
	else
		TR0=1;
}
}
void timer0() interrupt 1
{
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	count++;
	if(count==20)
	{
		count=0;
		P2--;
		if(P2==0xf0)
			P2=0xff;
	}
}