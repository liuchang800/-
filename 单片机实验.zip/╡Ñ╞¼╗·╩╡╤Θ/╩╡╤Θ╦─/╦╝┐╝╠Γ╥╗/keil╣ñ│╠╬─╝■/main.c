#include <REGX51.H>
unsigned int i;
void main()
{
	EA=1;
	ET0=1;
	TMOD=0x01;
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	TR0=1;
	P2=0xff;
	while(1);
}
void timer0() interrupt 1
{
	
	i++;
	if(i==20)
	{
		i=0;
		P2--;
		if(P2==0xf0)
		{
			P2=0xff;
		}
	}
	
}

